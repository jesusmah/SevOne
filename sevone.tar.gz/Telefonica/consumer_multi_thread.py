#!./bin/python3

from confluent_kafka import Consumer
import json
import sys
import os
import shutil
import threading
import time
import signal
from datetime import datetime

# Global shutdown signal
shutdown_event = threading.Event()

# Redirect all stdout and stderr to a file
log_file_name = 'output.log'
if os.path.exists(log_file_name):
    os.remove(log_file_name)
log_file = open(log_file_name, 'a')
sys.stdout = log_file
sys.stderr = log_file

# Topics
# TOPICS = [
#     "test-jesus-topic",
#     "test-jesus-topic-2"
#     ]
TOPICS = [
    # "alc1-jun-metrics",
    # "alc2.alc1-jun-metrics",
    # "alc2.apstra-metrics",
    # "alc2.cism1-alc1-hpe-metrics",
    # "alc2.cism1-alc1-ocp-metrics",
    # "alc2.cism2-alc2-hpe-metrics",
    # "alc2.cism2-alc2-ocp-metrics",
    # "alc2.cwl-site1-ocp-metrics",
    # "alc2.cwl-site2-ocp-metrics",
    # "alc2.mgmt1-alc1-hpe-metrics",
    # "alc2.mgmt1-alc1-ocp-metrics",
    # "alc2.mgmt1-alc2-hpe-metrics",
    # "alc2.mgmt1-alc2-ocp-metrics",
    # "alc2.mgmt1-ocp-metrics",
    # "alc2.mgmt2-ocp-metrics",
    # "alc2.orch-metrics",
    # "alc2.stf-metrics",
    # "alc2.vim1-alc1-hpe-metrics",
    # "alc2.vim1-alc1-ocp-metrics",
    # "alc2.vim1-alc1-osp-metrics",
    # "alc2.vim2-alc2-hpe-metrics",
    # "alc2.vim2-alc2-ocp-metrics",
    # "alc2.vim2-alc2-osp-metrics",
    "apstra-metrics",
    # "cism1-alc1-hpe-metrics",
    # "cism1-alc1-ocp-metrics",
    # "cism2-alc2-hpe-metrics",
    # "cism2-alc2-ocp-metrics",
    # "mgmt1-alc1-hpe-metrics",
    # "mgmt1-alc1-ocp-metrics",
    # "mgmt1-alc2-hpe-metrics",
    # "mgmt1-alc2-ocp-metrics",
    "orch-metrics"
    # "vim1-alc1-hpe-metrics",
    # "vim1-alc1-ocp-metrics",
    # "vim1-alc1-osp-metrics",
    # "vim2-alc2-hpe-metrics",
    # "vim2-alc2-ocp-metrics",
    # "vim2-alc2-osp-metrics"
    ]

# Directories
TMP_OUTPUT_DIR = 'tmp-output'
DEST_DIR = 'dest'
os.makedirs(TMP_OUTPUT_DIR, exist_ok=True)
os.makedirs(DEST_DIR, exist_ok=True)

for topic in TOPICS:
    os.makedirs(DEST_DIR + "/" + topic, exist_ok=True)

# Rotation
ROTATION = 1

def log(mensaje):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] - {mensaje}", flush=True)

def get_filename(topic):
    """Generate a timestamped filename rounded to the nearest 5 minutes."""
    now = datetime.utcnow()
    minute_group = now.minute - (now.minute % ROTATION)
    rounded_time = now.replace(minute=minute_group, second=0, microsecond=0)
    filename = f"{topic}_{rounded_time.strftime('%Y%m%d_%H%M')}.txt"
    return filename


def consume_topic(topic):
    """Consume messages from a single topic in its own thread."""
    # Consumer configuration json file
    config_json = "config/consumer_config.json"

    config = {}
    try:
        with open(config_json, 'r') as config_file:
            config = json.load(config_file)
            # Process the content of the file
    except FileNotFoundError:
        log(f"[Thread {topic}][Error] - {config.json} file not found.  The default configuration is config/consumer_config.json.")
        sys.exit(1)
    except IOError:
        log(f"[Thread {topic}][Error] - Could not read {config.json}. Try adjusting the permissions or formatting of {config.json} file so it can be read.")
        sys.exit(1)

    #config['group.id'] = f"{config['group.id']}-{topic}"

    # Print Consumer config for debugging purposes
    log("[Thread {}] - {}".format(topic,json.dumps(config, indent=2)))

    # Create Consumer instance
    consumer = Consumer(config)

    # Subscribe to topic
    consumer.subscribe([topic])

    # Poll for new messages from Kafka and print them.
    try:
        current_filename = get_filename(topic)
        current_filepath = os.path.join(TMP_OUTPUT_DIR, current_filename)
        current_file = open(current_filepath, 'a')
        log(f"[Thread {topic}] - Started logging to {current_filepath}")

        while not shutdown_event.is_set():
            msg = consumer.poll(timeout=10.0)

            # Rotate file if needed
            new_filename = get_filename(topic)
            if new_filename != current_filename:
                # Close old file
                current_file.close()

                # Only move files with events
                if os.path.getsize(current_filepath) > 0:
                    # Move the file
                    dest_path = os.path.join(DEST_DIR + "/" + topic, current_filename)
                    shutil.move(current_filepath, dest_path)
                    log(f"[Thread {topic}] - Moved {current_filename} to {DEST_DIR}.")
                else:
                    # Remove the file
                    os.remove(current_filepath)
                    log(f"[Thread {topic}] - Removed empty file {current_filename}.")

                # Start new file
                current_filename = new_filename
                current_filepath = os.path.join(TMP_OUTPUT_DIR, current_filename)
                current_file = open(current_filepath, 'a')
                log(f"[Thread {topic}] - Started logging to {current_filepath}")

            if msg is None:
                # Initial message consumption may take up to
                # `session.timeout.ms` for the consumer group to
                # rebalance and start consuming
                log(f"[Thread {topic}] - Waiting...")
            elif msg.error():
                log("[Thread {}][ERROR] - {}".format(topic,msg.error()))
            else:
                # Extract the (optional) key and value, and print.
                #print("Consumed event from topic {topic}: key = {key} value = {value}".format(topic=msg.topic(), key=str(msg.key()), value=msg.value().decode('utf-8')))

                #line = f"Key: {msg.key()}, Value: {msg.value().decode('utf-8')}, Offset: {msg.offset()}\n"
                #print(line.strip())
                line = msg.value().decode('utf-8').strip()
                # print(line)
                current_file.write(line + '\n')
                current_file.flush()

    finally:
        log(f"[Thread {topic}] - Exiting...")
        # Close file
        current_file.close()
        if os.path.exists(current_filepath):
            # Only move files with events
            if os.path.getsize(current_filepath) > 0:
                # Move the file
                dest_path = os.path.join(DEST_DIR + "/" + topic, current_filename)
                shutil.move(current_filepath, dest_path)
                log(f"[Thread {topic}] - Moved {current_filename} to {DEST_DIR}.")
            else:
                # Remove the file
                os.remove(current_filepath)
                log(f"[Thread {topic}] - Removed empty file {current_filename}.")
        # Leave group and commit final offsets
        consumer.close()

def handle_shutdown(signum, frame):
    log(f"[MAIN] - Received signal {signum}. Shutting down...")
    shutdown_event.set()

# Register signal handlers
signal.signal(signal.SIGTERM, handle_shutdown)  # kill PID
signal.signal(signal.SIGINT, handle_shutdown)   # Ctrl+C or kill -2 PID

if __name__ == '__main__':

    log(f"[MAIN] - START")

    threads = []
    for topic in TOPICS:
        thread = threading.Thread(target=consume_topic, args=(topic,))
        thread.start()
        threads.append(thread)

    # Wait for all threads to complete
    try:
        while any(t.is_alive() for t in threads):
            time.sleep(1)
    except Exception as e:
        log("[MAIN] - Main thread interrupted. Exiting...") 
        shutdown_event.set()  # Notify threads to stop

    for thread in threads:
            thread.join()

    log("[MAIN] - Main thread finished.") 

    # Close log file
    log_file.close()


    
