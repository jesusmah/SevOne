import re
import requests
import json
import time
import urllib3
import csv
import os
import datetime
import time
from random import random
import math

urllib3.disable_warnings()


#NMS Connection
nms = '127.0.0.1'
nmsuser = 'admin'
nmspass = "y5x0je8DE*c4ANa"
nmsheaders = {
	"Content-Type": "Application/json",
	"Accept": "Application/json"
}



#NMS authentication
def s1_authenticate():
	url = 'https://'+nms+'/api/v2/authentication/signin'

	data = {
		"name": nmsuser,
		"password": nmspass
	}
	response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)
	#print(response.text)
	result = json.loads(response.text)
	#print(result.text)
	token = result['token']
	return token
	#print(token)

#NMS Check if device is in NMS, otherwise add it
def s1_check_device(device):
	url = 'https://'+nms+'/api/v3/metadata/devices'
	data = {
		"deviceNames": [ {
			"fuzzy": False,
			"value": device
		}]
	}
	response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)
	result = json.loads(response.text)
	#print(result['devices'])
	if len(result['devices']) == 0:
		devicedetails = s1_add_device(device)
		return devicedetails
	else:
		return result['devices'][0]



def s1_add_device(device):
	url = 'https://'+nms+'/api/v3/devices'
	data = {
		"name": device,
		"ipAddress": '0.0.0.0',
		"description": 'Automatically Created by API'
	}
	response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)
	#print(device)
	result = s1_check_device(device)
	#print(result)
	return result

		
#Checks if objecttype exists, if it doesn't, it creates the object type
def s1_check_objectype(objecttypename):
	url = 'https://'+nms+'/api/v3/metadata/object_types'
	data = {
		"names": [{
			"fuzzy": False,
			"value": objecttypename
		}]
	}
	#print(data)
	response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)
	result = json.loads(response.text)
	#print(result)
	if len(result['objectTypes']) == 0 :
		url = 'https://'+nms+'/api/v2/plugins/objecttypes'
		data = {
			"extendedInfo": {},
			"isEditable": True,
			"isEnabled": True,
			"name": objecttypename,
			"pluginId": 10
		}
		response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)
		#print("objecttype created")
		#print(response)
	else:
		#print("objecttype already created ",objecttypename)
		return result['objectTypes'][0]['id']

#Checks if the indicator exists, if it doesn't, it creates the indicator type
def s1_check_indicator(objecttypename,indicatorname, units, format):
	pluginObjectTypeId = s1_check_objectype(objecttypename)
	url = 'https://'+nms+'/api/v2/plugins/indicatortypes/filter'
	data = {
		"pluginObjectTypeId": pluginObjectTypeId,
		"name": indicatorname
	}
	#print(data)
	response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)
	result = json.loads(response.text)
	total = result['totalElements']
	#print(result)
	if total==0 :
		url = 'https://'+nms+'/api/v2/plugins/indicatortypes'
		data = {
			"allowMaximumValue": False,
			"dataUnits": units,
			"description": indicatorname,
			"displayUnits": units,
			"extendedInfo": None,
			"format": format,
			"isDefault": True,
			"isEnabled": True,
			"name": indicatorname,
			"pluginObjectTypeId": pluginObjectTypeId,
			"syntheticExpression": None,
			"syntheticMaximumExpression": None
		}
		response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)


def s1_get_indicators_from_objecttype(objecttypename):
	url = 'https://'+nms+'/api/v3/metadata/object_types'
	data = {
		"names": [{
			"fuzzy": False,
			"value": objecttypename
		}]
	}
	response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)
	result = json.loads(response.text)
	pluginObjectTypeId = result['objectTypes'][0]['id']
	url = 'https://'+nms+'/api/v2/plugins/indicatortypes/filter'
	data = {
		"pluginObjectTypeId": pluginObjectTypeId,
	}
	response =requests.post(url,headers = nmsheaders ,data=json.dumps(data),verify=False)
	result = json.loads(response.text)
	return result['content']

#Insert data into NMS
def insert_data(devicedetails,objecttypename,objectname, dict):
	devicename = devicedetails['name']
	if 'ip' in devicedetails:
		ip = devicedetails['ip']
	else:
		ip = devicedetails['ipAddress']
	#Check if objectype exists
	#s1_check_objectype(objecttypename)

	#Prepare body to insert data
	body ={}
	body['name'] = devicename
	body['ip']=ip
	body['type'] = devicename
	
	body['automaticCreation']= True
	objects = []
	
	objectdict = {}
	objectdict['name'] = objectname
	objectdict['type'] = objecttypename
	objectdict['description'] = objectname
	objectdict['pluginName'] = "DEFERRED"
	objectdict['automaticCreation']= True
	timestamps = []
		
	timestampsdict = {}
	timestampsdict['timestamp']= str(round(timestamp))
	indicators = []
	
	for indicatorname in dict:
		#s1_check_indicator(objecttypename,indicatorname, 'Number', 'GAUGE')
		timestampsdictarraydict = {
			"name": indicatorname,
			"value": dict[indicatorname]
		}
			
		indicators.append(timestampsdictarraydict)

		timestampsdict['indicators']= indicators

	timestamps.append(timestampsdict)
	
	
	objectdict['timestamps']= timestamps
	
	objects.append(objectdict)
	body['objects']= objects
	#body['oldTs']= round(mintimestamp)
	#body['newTs']= round(maxtimestamp)

	#Post results
	url = 'https://'+nms+'/api/v3/devices/data'
	done=False
	try:
		response =requests.post(url,headers = nmsheaders,data=json.dumps(body),verify=False)
		result = json.loads(response.text)
		print(result)
		if result is not None:
			done = True
		
		#print(body)
		return result
	except:
		print('ingestion failed')

timestamp = time.time()
path = "/config/apstra/"
files = os.listdir(path)
nmsheaders['x-auth-token'] = s1_authenticate()

for file in files:
	filename = path+file
	if not os.path.isdir(os.path.join(path, file)) and "apstra" in file and file != "apstra_collector.py" :
	
		dict = {}
		#print(filename)
		with open(filename) as jsondata:
			#print(jsondata.read())
			data  = jsondata.read()
			jsondata.close()
			#cleandata = data.replace("NEW MESSAGE","")
			data = data.splitlines()
			#print(len(cleandata))
			for i in range(len(data)):
				#print(data[i])
				if data[i] and data[i] != "NEW MESSAGE":
					d = json.loads(data[i])
					device = d["tags"]["device"]
					objecttype = d["tags"]["receiver"]
					object = d["tags"]["interface"]
					if device not in dict:
						dict[device] = {}

					dict[device][object] = [objecttype, {
					 		"alignment_errors": d["fields"]["alignment_errors"],
					 		"delta_seconds": d["fields"]["delta_seconds"],
    						"fcs_errors": d["fields"]["fcs_errors"],
    						"giants": d["fields"]["giants"],
    						"runts": d["fields"]["runts"],
    						"rx_bps": d["fields"]["rx_bps"],
    						"rx_broadcast_packets": d["fields"]["rx_broadcast_packets"],
    						"rx_broadcast_pps": d["fields"]["rx_broadcast_pps"],
    						"rx_bytes": d["fields"]["rx_bytes"],
    						"rx_discard_packets": d["fields"]["rx_discard_packets"],
    						"rx_discard_pps": d["fields"]["rx_discard_pps"],
   							"rx_error_packets": d["fields"]["rx_error_packets"],
    						"rx_error_pps": d["fields"]["rx_error_pps"],
						    "rx_multicast_packets": d["fields"]["rx_multicast_packets"],
    						"rx_multicast_pps": d["fields"]["rx_multicast_pps"],
    						"rx_unicast_packets": d["fields"]["rx_unicast_packets"],
    						"rx_unicast_pps": d["fields"]["rx_unicast_pps"],
    						"symbol_errors": d["fields"]["symbol_errors"],
						    "tx_bps": d["fields"]["tx_bps"],
    						"tx_broadcast_packets": d["fields"]["tx_broadcast_packets"],
    						"tx_broadcast_pps": d["fields"]["tx_broadcast_pps"],
						    "tx_bytes": d["fields"]["tx_bytes"],
    						"tx_discard_packets": d["fields"]["tx_discard_packets"],
    						"tx_discard_pps": d["fields"]["tx_discard_pps"],
    						"tx_error_packets": d["fields"]["tx_error_packets"],
   							"tx_error_pps": d["fields"]["tx_error_pps"],
    						"tx_multicast_packets": d["fields"]["tx_multicast_packets"],
    						"tx_multicast_pps": d["fields"]["tx_multicast_pps"],
    						"tx_unicast_packets": d["fields"]["tx_unicast_packets"],
    						"tx_unicast_pps": d["fields"]["tx_unicast_pps"]
					 	}]
					
			#print(dict)
		#with open(filename, newline='\n') as csvfile:
		#    spamreader = csv.reader(csvfile, delimiter=',')
		#    for row in spamreader:
		#    	donotinsert = False
		#    	#print(row)
		#    	if row[1] :
		#	    	device = row[0]
		#	    	if "¿" in device:
		#	    		device = device[3:]
		#	    	objecttype = row[1]
		#	    	object = row[2]
		#	    	indicator = row[3]
		#	    	value = row[4]
		#	    	if "ms" in value:
		#	    		value = int(re.search(r'\d+', value).group())
		#	    		#print("ms " + str(value))
		#	    	elif len(re.findall(r"[-+]?\d*\.\d+", value)) > 0:
		#	    		temp = re.findall(r"[-+]?\d*\.\d+", value)
		#	    		value = temp[0]
		#	    		#print("float " + str(value))
		#	    	elif len((re.findall(r'\d+', value))) == 0:
		#	    		donotinsert = True
		#	    		#print("not added " + value)
		#	    	#elif isinstance(value, int):
		#	    	#	value = int(value)
		#	    	#elif isinstance(value, str):
		#	    	#	donotinsert = True
		#	    	elif "Status" in value or ":" in value:
		#	    		value = int(re.search(r'\d$', value).group())
		#	    	elif "Vendor=" in value:
		#	    		donotinsert == True	
		#	    	else:
		#	    		value = int(value)
		#	    		#print("int " + str(value))

		#	    	if donotinsert == False:
		#		    	if device in dict:
		#		    		if object in dict[device]:
		#		    			dict[device][object][1][indicator] = value
		#		    		else:
		#		    			ti = {
		#		    				indicator: value
		#		    			}
		#		    			dict[device][object] = [objecttype,ti]
		#		    	else:
		#		    		ti = {
		#		    				indicator: value
		#		    		}
		#		    		to = {
		#		    			object: [objecttype, ti]
		#		    		}
		#		    		dict[device] = to
		#		    	#print("device " + device + " type " + objecttype + " object " + object + " indicator " + indicator + " value: " + str(value))
		#	    	#print("device " + device + " type " + objecttype + " object " + object + " indicator " + indicator + " value: " + str(value))
		##print(dict)
		for key in dict:
			devicedetails = s1_check_device(key)
			newdict = dict[key]
			#print(devicedetails)
			for key2 in newdict:
				cobjectname = key2
				cobjecttype = dict[key][key2][0]
				cdict = dict[key][key2][1]
				insert_data(devicedetails,cobjecttype,cobjectname,cdict)

		#os.rename(filename,path+"old/"+file)

				